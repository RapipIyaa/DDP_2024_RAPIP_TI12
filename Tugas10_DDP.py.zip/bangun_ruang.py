def hitung_luas_kubus(sisi):
    return 6 * (sisi ** 2)

def hitung_luas_balok(panjang, lebar, tinggi):
    return 2 * (panjang * lebar + panjang * tinggi + lebar * tinggi)
